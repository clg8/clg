import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.datasets import make_blobs

# Create dataset (satisfies K-Means algorithm application)
X, _ = make_blobs(n_samples=300, centers=4, cluster_std=0.60, random_state=0)

# Apply K-Means algorithm (satisfies K-Means algorithm application)
kmeans = KMeans(n_clusters=4)
kmeans.fit(X)
y_kmeans = kmeans.predict(X)

# Determine the optimal number of clusters using the Elbow Method
wcss = []  # List to store WCSS values
for i in range(1, 11):
    kmeans = KMeans(n_clusters=i)
    kmeans.fit(X)
    wcss.append(kmeans.inertia_)

# Elbow method plot (satisfies optimal number of clusters determination)
plt.plot(range(1, 11), wcss)
plt.title('Elbow Method')  # Title of the plot
plt.xlabel('Number of Clusters')  # X-axis label
plt.ylabel('WCSS')  # Y-axis label
plt.show()

# Visualize the clustering results (satisfies visualization of clusters)
plt.scatter(X[:, 0], X[:, 1], c=y_kmeans, s=50, cmap='viridis')
centers = kmeans.cluster_centers_  # Get the cluster centers
plt.scatter(centers[:, 0], centers[:, 1], c='red', s=200, alpha=0.5)  # Plot centroids in red
plt.title('K-Means Clustering Results')  # Title of the plot
plt.show()
